package mdane.myapplication6.Jobs;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;

import com.evernote.android.job.Job;
import com.evernote.android.job.JobRequest;

import mdane.myapplication6.SMS.ListenSmsMmsService;
import mdane.myapplication6.Services.MyService;

/**
 * Created by - on 6/11/2017.
 */


    public class DemoSyncJob extends Job {

        public static final String TAG = "StartService";
  Context context; Intent intent;
        @Override
        @NonNull
        protected Result onRunJob(Params params) {
Intent a=new Intent(getContext(), MyService.class);
            getContext().getApplicationContext().startService(a);
           Intent B=new Intent(getContext(), ListenSmsMmsService.class);
            getContext().getApplicationContext().startService(B);
            // run your job here
            return Job.Result.SUCCESS;
        }

        public static void scheduleJob() {
            new JobRequest.Builder(DemoSyncJob.TAG)
                    .setExecutionWindow(30_000L, 40_000L)
                    .build()
                    .schedule();
        }
    }

